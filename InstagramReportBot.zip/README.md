# InstaReport

This is a script which reports targeted instagram accounts and instagram videos in bulk.
Version : 2.0.1

[![forthebadge Made-With-Python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

### Features

This is a script which reports targeted instagram account or an instagram video.
Works On

```
[+] Powerful ban tool
[+] Uses proxy + username
[+] Mass report on instagram account
[+] Mass report on instagram video
[+] Gatthering information about instagram account (Comming soon)

```

## Requirements

[Python3 Or Above](https://www.python.org/downloads/)

No need to install git in linux or termux

[Download GIT](https://git-scm.com/downloads)

# Usage

### INSTALLATION [Termux] (Not working for android right now)

- `apt update`
- `apt upgrade`
- `pkg install python`
- `pkg install python3`
- `pkg install git`
- `git clone https://github.com/Crevils/InstaReport`
- `cd instareport`
- `pip install -r requirements.txt`
- `chmod +x *`
- `bash setup.sh` OR `python ReportBot.py`

### INSTALLATION [Windows]

[Download python](https://www.python.org/downloads/) and [git](https://git-scm.com/downloads)

- `git clone https://github.com/Crevils/InstaReport`
- `cd instareport`
- `pip install -r requirements.txt`
- `python ReportBot.py`
- [ - ] If You Don't want to install git then download this tool zip manually

### INSTALLATION [Kali Linux]

- `sudo apt install python`
- `sudo apt install python3`
- `sudo apt install git`
- `git clone https://github.com/Crevils/InstaReport`
- `cd instareport`
- `pip3 install -r requirements.txt`
- `chmod +x *`
- `sudo bash setup.sh`

## Warning:

#### This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases
